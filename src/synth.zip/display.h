#ifndef DISPLAY_H
#define DISPLAY_H

void setupOLED();
void drawVolumeBar(float volume);

#endif
